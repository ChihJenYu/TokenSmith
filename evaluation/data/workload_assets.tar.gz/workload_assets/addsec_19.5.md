## 19.5 Protecting Against Media Failures

The log can protect us against system failures, where nothing is lost from disk, 
but temporary data in main memory is lost. However, as we discussed in 
Section 17.1.1, more serious failures involve the loss of one or more disks. An 
archiving system, which we cover next, is needed to enable a database to survive 
losses involving disk-resident data.

## 19.5.1 The Archive

To protect against media failures, we are thus led to a solution involving archiving — maintaining a copy of the database separate from the database itself. If 
it were possible to shut down the database for a while, we could make a backup 
copy on some storage medium such as tape or optical disk, and store the copy 
remote from the database, in some secure location. The backup would preserve 
the database state as it existed at the time of the backup, and if there were a 
media failure, the database could be restored to this state.

To advance to a more recent state, we could use the log, provided the log 
had been preserved since the archive copy was made, and the log itself survived 
the failure. In order to protect against losing the log, we could transmit a copy 
of the log, almost as soon as it is created, to the same remote site as the archive. 
Then, if the log as well as the data is lost, we can use the archive plus remotely 
stored log to recover, at least up to the point that the log was last transmitted 
to the remote site.

Since writing an archive is a lengthy process, we try to avoid copying the 
entire database at each archiving step. Thus, we distinguish between two levels 
of archiving:

1. A full dump, in which the entire database is copied.
2. An incremental dump, in which only those database elements changed 
since the previous full or incremental dump are copied.

It is also possible to have several levels of dump, with a full dump thought of as 
a “level 0” dump, and a “level i” dump copying everything changed since the 
last dump at a level less than or equal to i.
We can restore the database from a full dump and its subsequent incremental 
dumps, in a process much like the way a redo or undo/redo log can be used 
to repair damage due to a system failure. We copy the full dump back to the 
database, and then in an earliest-first order, make the changes recorded by the 
later incremental dumps.

## 19.5.2 Nonquiescent Archiving

The problem with the simple view of archiving in Section 17.5.1 is that most 
databases cannot be shut down for the period of time (possibly hours) needed
to make a backup copy. We thus need to consider nonquiescent archiving,
which is analogous to nonquiescent checkpointing. Recall that a nonquiescent 
checkpoint attempts to make a copy on the disk of the (approximate) database 
state that existed when the checkpoint started. We can rely on a small portion 
of the log around the time of the checkpoint to fix up any deviations from that 
database state, due to the fact that during the checkpoint, new transactions 
may have started and written to disk.
Similarly, a nonquiescent dump tries to make a copy of the database that 
existed when the dump began, but database activity may change many database 
elements on disk during the minutes or hours that the dump takes. If it is 
necessary to restore the database from the archive, the log entries made during 
the dump can be used to sort things out and get the database to a consistent 
state.

Why Not Just Back Up the Log?
We might question the need for an archive, since we have to back up the log 
in a secure place anyway if we are not to be stuck at the state the database 
was in when the previous archive was made. While it may not be obvious, 
the answer lies in the typical rate of change of a large database. While 
only a small fraction of the database may change in a day, the changes, 
each of which must be logged, will over the course of a year become much 
larger than the database itself. If we never archived, then the log could 
never be truncated, and the cost of storing the log would soon exceed the 
cost of storing a copy of the database.

A nonquiescent dump copies the database elements in some fixed order, 
possibly while those elements are being changed by executing transactions. As 
a result, the value of a database element that is copied to the archive may or 
may not be the value that existed when the dump began. As long as the log 
for the duration of the dump is preserved, the discrepancies can be corrected 
from the log.

E xam ple 17.13 : For a very simple example, suppose that our database consists of four elements, A, B, C, and D, which have the values 1 through 4, 
respectively, when the dump begins. During the dump, A is changed to 5, C
is changed to 6, and B is changed to 7. However, the database elements are 
copied in order, and the sequence of events shown in Fig. 17.12 occurs. Then 
although the database at the beginning of the dump has values (1,2,3,4), and 
the database at the end of the dump has values (5,7,6,4), the copy of the 
database in the archive has values (1,2,6,4), a database state that existed at 
no time during the dump. □
Disk Archive
Copy A
A := 5
Copy B
C := 6
Copy C
B := 7
Copy D
Figure 17.12: Events during a nonquiescent dump
In more detail, the process of making an archive can be broken into the 
following steps. We assume that the logging method is either redo or undo/redo; 
an undo log is not suitable for use with archiving.
1. Write a log record <START DUMP>.
2. Perform a checkpoint appropriate for whichever logging method is being 
used.
3. Perform a full or incremental dump of the data disk(s), as desired, making 
sure that the copy of the data has reached the secure, remote site.
4. Make sure that enough of the log has been copied to the secure, remote 
site that at least the prefix of the log up to and including the checkpoint 
in item (2) will survive a media failure of the database.
5. Write a log record <END DUMP>.

At the completion of the dump, it is safe to throw away log prior to the beginning 
of the checkpoint previous to the one performed in item (2) above.
E xam ple 17.14: Suppose that the changes to the simple database in Example 17.13 were caused by two transactions T\ (which writes A and B) and T2 
(which writes C) that were active when the dump began. Figure 17.13 shows 
a possible undo/redo log of the events during the dump.
< START DUMP>
< START CKPT (Ti ,T2)>
< T i,A , 1,5>
<T2,C ,3 ,6 >
<C0MMIT T2>
<Ti ,B ,2 ,7 >
<END CKPT>
Dump completes 
<END DUMP>
Figure 17.13: Log taken during a dump
Notice that we did not show 7\ committing. It would be unusual that a 
transaction remained active during the entire time a full dump was in progress, 
but that possibility doesn’t affect the correctness of the recovery method that 
we discuss next. 

## 19.5.3 Recovery Using an Archive and Log

Suppose that a media failure occurs, and we must reconstruct the database 
from the most recent archive and whatever prefix of the log has reached the 
remote site and has not been lost in the crash. We perform the following steps:
1. Restore the database from the archive.
(a) Find the most recent full dump and reconstruct the database from 
it (i.e., copy the archive into the database).
(b) If there axe later incremental dumps, modify the database according 
to each, earliest first.
2. Modify the database using the surviving log. Use the method of recovery 
appropriate to the log method being used.
Example 17.15: Suppose there is a media failure after the dump of Example 17.14 completes, and the log shown in Fig. 17.13 survives. Assume, to make 
the process interesting, that the surviving portion of the log does not include a 
<C0MMIT T\> record, although it does include the CCOMMIT T2> record shown
in that figure. The database is first restored to the values in the archive, which 
is, for database elements A, B, C, and D, respectively, (1,2,6,4).
Now, we must look at the log. Since T2 has completed, we redo the step 
that sets C to 6. In this example, C already had the value 6, but it might be 
that:
a) The archive for C was made before T2 changed C, or
b) The archive actually captured a later value of C, which may or may not 
have been written by a transaction whose commit record survived. Later 
in the recovery, C will be restored to the value found in the archive if the 
transaction was committed.
Since Ti does not have a COMMIT record, we must undo T i. We use the log 
records for T\ to determine that A must be restored to value 1 and B to 2. It 
happens that they had these values in the archive, but the actual archive value 
could have been different because the modified A and/or B had been included 
in the archive. 
